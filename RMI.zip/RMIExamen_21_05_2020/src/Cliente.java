import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import dist.clienteExamen;
import dist.proctoringUEx;

public class Cliente extends UnicastRemoteObject implements clienteExamen {
	protected Cliente() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}
	private static final long serialVersionUID = 1L;

	@Override
	public String obtenerImagenWebcam(String cadena_fecha) throws RemoteException {
		System.out.println(cadena_fecha);
		return "OK_CAPTURA";
	}
	public static void main (String[] args) {
		
		System.out.println ("Iniciando el cliente");
		System.setProperty("java.rmi.server.hostname", "10.147.20.32");
		try {
			proctoringUEx obj = (proctoringUEx)Naming.lookup("//10.147.20.193:1099/proctoringUEx");
			String result=obj.registrarCliente("76054025", "Romo Gonz�lez", "Juan");
			Cliente client=new Cliente();
			Naming.rebind("//10.147.20.32:1099/ServidorJuan",client);
			String resultadoRegistrarWebcam=obj.registrarWebcam("10.147.20.32", "ServidorJuan", result);
			System.out.println(resultadoRegistrarWebcam);
		} catch (MalformedURLException | RemoteException | NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
	}

	
}
